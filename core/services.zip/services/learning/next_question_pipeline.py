from __future__ import annotations

from dataclasses import dataclass

from packages.contracts.attempt import Attempt
from packages.contracts.learner import Learner
from packages.contracts.learning_session import (
    LearningSession,
)
from packages.contracts.question import Question
from packages.contracts.skill import Skill

from core.services.question_selector import (
    QuestionSelector,
)
from core.services.skill_selector import (
    SkillSelector,
)


@dataclass(slots=True)
class NextQuestionPipelineResult:
    """
    Result produced by the adaptive next-question pipeline.
    """

    skill: Skill | None

    question: Question | None

    finished: bool = False


class NextQuestionPipeline:
    """
    Adaptive Next Question Pipeline.

    Responsibilities
    ----------------
    • Select the next skill.
    • Select the next question.
    • Determine whether the learning session has finished.

    This pipeline is orchestration only.

    It never:

    • Persists repositories.
    • Updates learner progress.
    • Evaluates answers.
    • Modifies sessions.
    """

    def __init__(
        self,
        skill_selector: SkillSelector,
        question_selector: QuestionSelector,
    ) -> None:

        self._skill_selector = skill_selector
        self._question_selector = question_selector

    # ---------------------------------------------------------
    # Public API
    # ---------------------------------------------------------

    def execute(
        self,
        learner: Learner,
        session: LearningSession,
        skills: list[Skill],
        questions: list[Question],
        attempts: list[Attempt],
    ) -> NextQuestionPipelineResult:
        """
        Determine the learner's next adaptive question.
        """

        skill = self._select_skill(
            learner=learner,
            skills=skills,
        )

        if skill is None:
            return NextQuestionPipelineResult(
                skill=None,
                question=None,
                finished=True,
            )

        question = self._select_question(
            learner=learner,
            session=session,
            skill=skill,
            questions=questions,
            attempts=attempts,
        )

        if question is None:
            return NextQuestionPipelineResult(
                skill=skill,
                question=None,
                finished=True,
            )

        return NextQuestionPipelineResult(
            skill=skill,
            question=question,
            finished=False,
        )

    # ---------------------------------------------------------
    # Skill Selection
    # ---------------------------------------------------------

    def _select_skill(
        self,
        learner: Learner,
        skills: list[Skill],
    ) -> Skill | None:
        """
        Select the learner's next target skill.
        """

        return self._skill_selector.select_next_skill(
            learner=learner,
            skills=skills,
        )

    # ---------------------------------------------------------
    # Question Selection
    # ---------------------------------------------------------

    def _select_question(
        self,
        learner: Learner,
        session: LearningSession,
        skill: Skill,
        questions: list[Question],
        attempts: list[Attempt],
    ) -> Question | None:
        """
        Select the best question for the selected skill.
        """

        return self._question_selector.select_next_question(
            learner=learner,
            session=session,
            skill=skill,
            questions=questions,
            attempts=attempts,
        )