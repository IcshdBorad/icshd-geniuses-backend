from __future__ import annotations

from packages.contracts.learner import Learner
from packages.contracts.learning_session import LearningSession
from packages.contracts.question import Question
from packages.contracts.submit_answer_result import SubmitAnswerResult

from core.application.ports.learner_repository import LearnerRepository
from core.application.ports.session_repository import SessionRepository


class SessionFinalizer:
    """
    Finalizes a learning interaction.

    Responsibilities
    ----------------
    - Update session state.
    - Update learner statistics.
    - Persist modified aggregates.
    - Build the application response.

    This service never
    ------------------
    - Validates answers.
    - Creates attempts.
    - Calculates performance.
    - Generates recommendations.
    - Selects questions.
    """

    def __init__(
        self,
        learners: LearnerRepository,
        sessions: SessionRepository,
    ) -> None:
        self._learners = learners
        self._sessions = sessions

    # ---------------------------------------------------------
    # Public API
    # ---------------------------------------------------------

    def finalize(
        self,
        *,
        learner: Learner,
        session: LearningSession,
        question: Question,
        is_correct: bool,
        score: float,
        next_question: Question | None,
    ) -> SubmitAnswerResult:
        """
        Finalize the current learning step.
        """

        finished = next_question is None

        self._update_session(
            session=session,
            next_question=next_question,
            finished=finished,
        )

        self._update_learner(
            learner=learner,
            finished=finished,
        )

        self._persist(
            learner=learner,
            session=session,
        )

        return self._build_result(
            question=question,
            is_correct=is_correct,
            score=score,
            next_question=next_question,
            finished=finished,
        )

    # ---------------------------------------------------------
    # Session
    # ---------------------------------------------------------

    @staticmethod
    def _update_session(
        *,
        session: LearningSession,
        next_question: Question | None,
        finished: bool,
    ) -> None:
        """
        Update session state.
        """

        session.current_question_id = (
            next_question.identifier
            if next_question is not None
            else None
        )

        session.completed = finished

    # ---------------------------------------------------------
    # Learner
    # ---------------------------------------------------------

    @staticmethod
    def _update_learner(
        *,
        learner: Learner,
        finished: bool,
    ) -> None:
        """
        Update learner statistics.
        """

        if finished:
            learner.completed_sessions += 1

    # ---------------------------------------------------------
    # Persistence
    # ---------------------------------------------------------

    def _persist(
        self,
        *,
        learner: Learner,
        session: LearningSession,
    ) -> None:
        """
        Persist modified aggregates.
        """

        self._learners.save(learner)
        self._sessions.save(session)

    # ---------------------------------------------------------
    # Response
    # ---------------------------------------------------------

    @staticmethod
    def _build_result(
        *,
        question: Question,
        is_correct: bool,
        score: float,
        next_question: Question | None,
        finished: bool,
    ) -> SubmitAnswerResult:
        """
        Build the application response.
        """

        return SubmitAnswerResult(
            is_correct=is_correct,
            correct_answer=question.answer,
            score=score,
            next_question_id=(
                next_question.identifier
                if next_question is not None
                else None
            ),
            finished=finished,
        )