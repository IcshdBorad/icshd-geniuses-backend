from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from core.application.ports.attempt_repository import (
    AttemptRepository,
)
from core.application.ports.clock import Clock

from core.services.learning.answer_validator import (
    AnswerValidationResult,
)
from core.services.spaced_repetition import (
    SpacedRepetition,
)

from packages.contracts.attempt import Attempt
from packages.contracts.learner import Learner
from packages.contracts.learning_session import (
    LearningSession,
)
from packages.contracts.question import Question
from packages.contracts.learning.submit_answer_request import (
    SubmitAnswerRequest,
)


class AttemptFactory:
    """
    Factory responsible for creating Attempt entities.

    Responsibilities
    ----------------
    - Create immutable Attempt objects.
    - Determine review stage.
    - Calculate ease factor.
    - Schedule the next review.

    This service is completely stateless except for
    querying the previous learner attempt.
    """

    def __init__(
        self,
        attempts: AttemptRepository,
        spaced_repetition: SpacedRepetition,
        clock: Clock,
    ) -> None:

        self._attempts = attempts
        self._spaced_repetition = spaced_repetition
        self._clock = clock

    # ---------------------------------------------------------
    # Public API
    # ---------------------------------------------------------

    def create(
        self,
        learner: Learner,
        session: LearningSession,
        question: Question,
        request: SubmitAnswerRequest,
        validation: AnswerValidationResult,
    ) -> Attempt:
        """
        Build a new Attempt entity.
        """

        previous_attempt = (
            self._attempts.get_last_attempt(
                learner_id=learner.identifier,
                question_id=question.identifier,
            )
        )

        review_stage = self._calculate_review_stage(
            previous_attempt=previous_attempt,
            is_correct=validation.is_correct,
        )

        ease_factor = self._calculate_ease_factor(
            previous_attempt=previous_attempt,
            is_correct=validation.is_correct,
        )

        attempted_at = self._clock.now()

        next_review = self._calculate_next_review(
            attempted_at=attempted_at,
            review_stage=review_stage,
            is_correct=validation.is_correct,
        )

        return Attempt(
            identifier=str(uuid4()),
            learner_id=learner.identifier,
            session_id=session.identifier,
            question_id=question.identifier,
            submitted_answer=request.submitted_answer,
            is_correct=validation.is_correct,
            score=validation.score,
            duration_ms=request.duration_ms,
            attempted_at=attempted_at,
            review_stage=review_stage,
            ease_factor=ease_factor,
            next_review=next_review,
        )

    # ---------------------------------------------------------
    # Review Stage
    # ---------------------------------------------------------

    def _calculate_review_stage(
        self,
        previous_attempt: Attempt | None,
        is_correct: bool,
    ) -> int:

        if previous_attempt is None:
            return 0

        if not is_correct:
            return 0

        return min(
            previous_attempt.review_stage + 1,
            self._spaced_repetition.MAX_REVIEW_STAGE,
        )

    # ---------------------------------------------------------
    # Ease Factor
    # ---------------------------------------------------------

    def _calculate_ease_factor(
        self,
        previous_attempt: Attempt | None,
        is_correct: bool,
    ) -> float:

        previous_ease = (
            self._spaced_repetition.DEFAULT_EASE_FACTOR
            if previous_attempt is None
            else previous_attempt.ease_factor
        )

        return self._spaced_repetition.calculate_ease_factor(
            previous_ease_factor=previous_ease,
            is_correct=is_correct,
        )

    # ---------------------------------------------------------
    # Next Review
    # ---------------------------------------------------------

    def _calculate_next_review(
        self,
        attempted_at: datetime,
        review_stage: int,
        is_correct: bool,
    ) -> datetime:

        if not is_correct:
            return (
                attempted_at
                + self._spaced_repetition.INCORRECT_INTERVAL
            )

        return (
            attempted_at
            + self._spaced_repetition.get_review_interval(
                review_stage
            )
        )